void codegen();
void codegen()
{
  digitalWrite(26, HIGH);
  delay(1000);
  digitalWrite(26, LOW);
  delay(1000);
}
